# metricamente

Evolución de Entrega 1: tutor de métricas e indicadores con HTML/CSS/JavaScript, Node.js + Express, SQLite y un único agente mediante Gemini API. Se conservan la identidad visual y el recorrido concepto → fichas → quiz → score → feedback. Los cinco temas de Operaciones son contenido inicial, no un catálogo cerrado.

## Estado de implementación

El flujo local de estudio, evaluación y persistencia está probado. La integración agéntica está escrita y verificada con dobles explícitos, pero **BLOQUEADA EN VERIFICACIÓN REAL**: la API rechaza generación con gemini-2.5-flash para esta cuenta (HTTP 404), aunque permite consultar sus metadatos. No se ejecutaron corridas académicas finales ni se atribuyen a pruebas simuladas resultados de Gemini.

## Ejecutar

Requiere Node.js 22 o posterior y npm. Probado con Node.js 24.19.0. Si el equipo usa Node 18, seleccioná una versión compatible antes de instalar. better-sqlite3 contiene un componente nativo: instalar con la misma versión de Node que ejecutará el proyecto.

```sh
npm ci
```

Copiar `.env.example` a `.env` y completar `GEMINI_API_KEY` en el servidor. Configuración:

```text
GEMINI_API_KEY=
GEMINI_MODEL=gemini-2.5-flash
DATABASE_PATH=./db/metricamente.db
PORT=3000
HOST=127.0.0.1
```

```sh
npm start
```

Abrir http://127.0.0.1:3000. La base se crea automáticamente. Sin API key se pueden estudiar/evaluar los cinco módulos iniciales y guardar progreso; las funciones que requieren IA devuelven un error explícito. Un fallo de feedback no invalida un intento ya guardado.

El modelo es configurable. La documentación oficial consultada declara Search grounding y Structured Outputs para Gemini 2.5 Flash; el acceso efectivo de una cuenta debe comprobarse con su API key. No se selecciona un modelo alternativo silenciosamente.

## Uso

- Elegir un módulo inicial o escribir una intención y seleccionar concepto/ruta por área.
- Para contenido nuevo: interpretar, consultar progreso real, buscar y generar contenido validado.
- Una ruta es una propuesta; elegir un módulo inicia su preparación, no lo marca completado.
- Completar cinco respuestas. El servidor corrige el quiz congelado y guarda el intento antes de solicitar feedback.
- Aceptar o rechazar la recomendación. No se ejecuta automáticamente.
- Consultar la tabla Área | Métrica | Intentos | Último score | Mejor score.

## Arquitectura y archivos

`index.html`, `styles.css`, `app.js`: vistas existentes adaptadas, representación segura con DOM/textContent y acceso a API. `shared/scoring.js`: cálculo determinístico compartido; el servidor no confía en scores enviados por el cliente.

`server/app.js`: rutas HTTP, validación de entrada e identidad vinculada, archivos públicos permitidos. `database.js`: SQLite y restricciones de inmutabilidad. `store.js`: persistencia, agregados y snapshots. `quizzes.js`: selección/mezcla y congelación. `agent.js`: Gemini API con @google/genai, function calling de progreso, Google Search Grounding y salida estructurada. `validation.js`: AJV y referencias. `errors.js`: errores explícitos. `index.js`: arranque.

`data/seeds.json`: contenido y 30 preguntas adaptados de Entrega 1. Sin fuentes externas inventadas; se indica esa limitación en pantalla. `README.txt` permanece intacto como antecedente. La carpeta excluida no se usa en la aplicación ni en esta implementación.

`prompts/`: contrato y plantilla con las seis piezas. `schemas/`: module, quiz, route, feedback e interpret; AJV valida las estructuras y reglas adicionales. Los prompts/versiones y el schema se guardan con cada ejecución.

## API

Las peticiones de datos requieren `X-User-Id` con el UUID generado por el navegador. Si el body contiene user_id debe coincidir. No es autenticación: quien conozca un UUID podría hacerse pasar por ese perfil. No usar como control de acceso de información sensible.

| Método y ruta | Entrada principal | Responsabilidad |
|---|---|---|
| GET /api/health | — | Estado local y disponibilidad de configuración, sin secretos. |
| GET /api/modules | — | Módulos iniciales y del usuario. |
| POST /api/learning/interpret | intent, mode opcional | Interpretar concepto, área o necesidad de aclaración. |
| POST /api/learning/module | intent, area opcional | Buscar, validar y guardar módulo. |
| POST /api/learning/route | intent | Buscar y guardar propuesta de ruta. |
| POST /api/learning/quiz | module_id, version | Preparar, mezclar y congelar cinco preguntas. |
| POST /api/attempts | quiz_id, answers[5] | Calcular resultado y guardar intento inmutable. |
| POST /api/learning/feedback | attempt_id | Interpretar el intento real y recomendar. |
| GET /api/progress/:userId | area/metric opcionales | Historial y agregados derivados. |
| POST /api/decisions | run_id, decision accept/reject | Registrar una elección humana. |

Repetir el envío de las mismas respuestas para el mismo quiz devuelve el mismo intento (idempotencia). Cambiarlas después de guardar produce 409. Otro intento requiere otro quiz congelado. Las claves correctas llegan al navegador para el cálculo compartido: es una herramienta de autoaprendizaje, no un examen protegido contra consulta de respuestas.

## Datos persistidos

- users: user_id, created_at.
- modules: module_id + version (clave compuesta), user_id nullable para seeds, area, metric, content_json, sources_json, run_id, created_at.
- quizzes: quiz_id, module_id, module_version, user_id, version, quiz_json, run_id, created_at.
- attempts: attempt_id, user_id, quiz_id, answers_json, results_json, score, correct_count, created_at; unicidad user_id + quiz_id.
- agent_runs: run_id, user_id, operation, model, prompt_version, input_json, tool_calls_json, output_json, status, error, created_at.
- routes: route_id, user_id, route_json, run_id, created_at.
- decisions: decision_id, user_id, run_id, decision, created_at.

Los JSON completos y las relaciones reconstruyen módulo/version, quiz/version, preguntas/opciones en orden, claves, respuestas, resultados por pregunta y fuentes. Intentos y artefactos no admiten UPDATE/DELETE a través de la aplicación; SQLite también los bloquea con triggers. agent_runs puede finalizar desde running una vez; un registro terminal no se edita. Un administrador del archivo SQLite podría cambiar la base: no es un registro criptográficamente inviolable.

Los agregados se derivan de intentos. Se conserva el antiguo localStorage bajo su clave original, separado, sin fabricar intentos. Borrar el almacenamiento local pierde la asociación con el UUID; SQLite no se borra por ello. No hay recuperación de identidad ni sincronización de UUID entre dispositivos.

## Agente, fuentes y límites

El mismo agente usa una secuencia acotada: llamada real a get_learning_progress → búsqueda web para módulo/ruta → salida estructurada. Los quizzes se fundamentan en el módulo y referencias ya guardadas. Feedback recibe el score oficial y el intento desde SQLite, nunca desde una cifra proporcionada por el usuario. La herramienta propia expone solo consultas, sin SQL ni operaciones de escritura.

Google Search Grounding se invoca con models.generateContent y googleSearch. Se conserva groundingMetadata completo: webSearchQueries, groundingChunks, groundingSupports, searchEntryPoint y otros campos si la API los entrega. Solo las URIs de groundingChunks alimentan el contrato de fuentes; las URLs en texto libre no son evidencia recuperada. El código exige URLs recuperadas, IDs válidos y al menos una fuente clasificada nivel 1 o 2. La clasificación de autoridad y la corrección semántica dependen todavía del modelo y revisión humana: coincidencia de URL no prueba que una fórmula sea correcta.

Errores: búsqueda fallida no activa fallback interno; evidencia insuficiente devuelve insufficient_sources; estructura inválida tiene como máximo un reintento; SDK con retryOptions.attempts=1 (sin retry de transporte) y timeout de 60 s por petición. Una petición de grounding por módulo/ruta; Gemini determina sus consultas internas, sin prometer un máximo de tres. No hay bucles de herramientas ilimitados. Existe exclusión de solicitudes agénticas simultáneas por UUID dentro del proceso.

## Evidencia y pruebas

```sh
npm test
npm run smoke:agent
npm run export:run -- <user-id>
```

`npm test` usa SQLite real y dobles de Gemini identificados como fixture-only. `smoke:agent` requiere una clave, realiza un módulo nuevo con herramientas y registra el run; sin clave termina con código 2 y PENDIENTE DE VERIFICACIÓN REAL. No es una corrida académica final.

El exportador crea un snapshot nuevo del usuario en corridas/ sin sobrescribir y muestra SHA-256. Conserva solicitudes/respuestas, outputs de herramientas, uso reportado por API, fuentes, artefactos y errores. No incluye la API key. Ver corridas/README.md. Reconstruir lo guardado no equivale a obtener el mismo texto al ejecutar otra vez LLM + búsqueda.

## Gobierno, supervisión y economía

El agente busca/genera/interpreta/recomienda; el usuario inicia/responde/acepta/rechaza. Etiqueta L0–L4 **pendiente** de definiciones oficiales. No se inventa nivel.

Claves solo en servidor; archivos públicos en lista explícita; .env, SQLite y corridas locales excluidos de Git. SQLite guarda historial e inputs: limitar acceso al archivo y revisar snapshots antes de compartir. No ingresar información empresarial confidencial: intención y progreso se envían a Gemini para la operación. El servicio arranca ligado a loopback; una publicación compartida requiere revisar exposición, límites y protección contra abuso sin asumir que el UUID es un login.

No se midieron costos reales. agent_runs preserva model/usage por respuesta para calcularlos luego con las tarifas vigentes y costos de herramientas. Se conserva usageMetadata exacto, incluyendo promptTokenCount, candidatesTokenCount, thoughtsTokenCount, toolUsePromptTokenCount y totalTokenCount cuando estén presentes; no se inventan campos ausentes. El máximo de reintentos y los límites por llamada acotan consumo, pero no son un presupuesto monetario. Falta completar el análisis económico con ejecuciones reales.

Pendientes: smoke test real y acceso al modelo, validación pedagógica real de fuentes y claves generadas, tres corridas académicas, etiqueta L0–L4 y economía. Sin dashboard avanzado, login, múltiples agentes, RAG, flashcards o simuladores; continúan como roadmap.

## Fase 5: migración y free tier

Se retiró openai y se utiliza únicamente @google/genai. No se modificaron los schemas; responseMimeType application/json y responseJsonSchema reciben el contrato completo, con validación AJV posterior. No se simplifica preventivamente ninguna construcción. Se conserva el diseño por etapas: function calling → resultado SQLite → grounding si corresponde → JSON estructurado. Los thought signatures de las partes devueltas se conservan en el contexto, sin fabricar llamadas.

La regresión local de Fase 5 pasó 21 tests y cuatro escenarios de navegador. La reanudación del 12/09/2026 usó la clave local y el proyecto free tier confirmado por el usuario: una consulta de metadatos pasó y cinco solicitudes de generación devolvieron 404 por modelo no disponible para usuarios nuevos. No se recibió grounding, functionCall, JSON generado ni usageMetadata. V1/V2 FAIL y V3–V11 BLOCKED; logging de errores y redacción PASS. No se cambió de modelo ni se ejecutó Fase 6. Ver ../Informe-Fase5-Gemini.txt y ../Fase5-evidencia-real/.

Esta fase autoriza exclusivamente el free tier. No habilitar billing. Si la API exige pago, el adaptador devuelve paid_tier_required; ante 429 devuelve quota_exceeded sin reintentar ni cambiar de modelo. La clave no certifica por sí sola el nivel de facturación: antes de correr el smoke real, confirmar en el proyecto que se usa free tier. No se hizo análisis económico final.

El tratamiento de datos del free tier puede diferir del paid tier. Para esta versión académica no ingresar información empresarial confidencial ni datos personales sensibles. Los tests deben utilizar únicamente un UUID técnico y contenido de aprendizaje no confidencial. Consultar las condiciones vigentes de Google.

## Referencias de integración

- https://ai.google.dev/gemini-api/docs/models/gemini-2.5-flash
- https://ai.google.dev/gemini-api/docs/google-search
- https://ai.google.dev/gemini-api/docs/structured-output
- https://ai.google.dev/gemini-api/docs/function-calling
- https://ai.google.dev/gemini-api/docs/pricing
- https://ai.google.dev/gemini-api/terms
- https://googleapis.github.io/js-genai/release_docs/interfaces/types.GenerateContentConfig.html

Consultadas el 12 de septiembre de 2026. No sustituyen la verificación real del modelo y cuota del proyecto.
