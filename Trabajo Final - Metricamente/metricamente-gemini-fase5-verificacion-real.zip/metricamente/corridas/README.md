# Evidencia académica

Todavía no se realizaron las tres corridas finales. Los tests usan bases temporales y dobles explícitos; no son ejecuciones reales de OpenAI.

Para preservar evidencia real: `npm run export:run -- <user-id>` desde la raíz, con DATABASE_PATH apuntando a la base correcta. El UUID local puede consultarse en el navegador bajo `metricamente-user-id`.

El comando crea un archivo nuevo sin sobrescribir y muestra su SHA-256. Incluye módulos, fuentes, quizzes congelados, respuestas, scores oficiales, feedback, solicitudes y respuestas de API, herramientas y decisiones del usuario. Exporta el conjunto de evidencia del usuario (puede contener varias ejecuciones); run_id identifica cada ejecución. Los JSON quedan ignorados por Git por privacidad: revisar y seleccionar expresamente los snapshots académicos antes de versionarlos, sin alterar outputs reales. No compartir UUIDs de usuarios reales.

Reconstrucción: leer los artefactos guardados y recalcular el score con el quiz congelado. Rerun: ejecutar nuevamente el modelo y la búsqueda; no se promete texto idéntico. Un run en estado running indica una interrupción antes de terminar, nunca éxito.
