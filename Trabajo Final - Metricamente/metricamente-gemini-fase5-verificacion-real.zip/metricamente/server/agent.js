import { GoogleGenAI } from '@google/genai';
import fs from 'node:fs';
import { createHash,randomUUID } from 'node:crypto';
import { AppError } from './errors.js';
import { schemas,envelope,parseEnvelope,validateSources,validateQuizSources,safeUrl } from './validation.js';
import { ensureAlternative } from './quizzes.js';

const system=fs.readFileSync(new URL('../prompts/system_prompt.md',import.meta.url),'utf8');
const userTemplate=fs.readFileSync(new URL('../prompts/user_prompt.md',import.meta.url),'utf8');
export const promptVersion=createHash('sha256').update(system+userTemplate+JSON.stringify(schemas)).digest('hex');
const progressTool={name:'get_learning_progress',description:'Consulta de solo lectura del historial real persistido del usuario vinculado. No ejecuta escrituras.',
  parametersJsonSchema:{type:'object',additionalProperties:false,required:['user_id','area','metric'],properties:{
    user_id:{type:'string'},area:{type:['string','null']},metric:{type:['string','null']}}}};

function textOf(response) {
  return (response.candidates?.[0]?.content?.parts||[]).filter(p=>typeof p.text==='string'&&!p.thought).map(p=>p.text).join('\n');
}
export function retrievedSources(response) {
  const map=new Map();
  for(const chunk of response.candidates?.[0]?.groundingMetadata?.groundingChunks||[]) {
    if(safeUrl(chunk.web?.uri)) map.set(chunk.web.uri,{url:chunk.web.uri,title:chunk.web.title||chunk.web.uri});
  }
  return [...map.values()];
}
export function redactEvidence(value,apiKey) {
  return JSON.parse(JSON.stringify(value,(name,v)=>{
    if(['apikey','api_key','authorization','x-goog-api-key'].includes(name.toLowerCase())) return '[REDACTED]';
    if(typeof v!=='string') return v;
    return (apiKey?v.split(apiKey).join('[REDACTED]'):v).replace(/AIza[A-Za-z0-9_-]{35}/g,'[REDACTED]');
  }));
}
export function createAgent(store,{apiKey=process.env.GEMINI_API_KEY,model=process.env.GEMINI_MODEL||'gemini-2.5-flash',client}={}) {
  const api=client || (apiKey?new GoogleGenAI({apiKey,vertexai:false,httpOptions:{timeout:60000,retryOptions:{attempts:1}}}):null);
  const clean=v=>redactEvidence(v,apiKey);
  return {
    model,configured:Boolean(api),
    async run(operation,userId,data) {
      const runId=randomUUID();
      const trace=[];
      let output=null;
      const input={operation,user_id:userId,...data};
      store.startRun({run_id:runId,user_id:userId,operation,model,prompt_version:promptVersion,
        input:clean({request:input,system_prompt:system,user_prompt_template:userTemplate,schema:envelope(operation),provider:'gemini'})});
      try {
        if(!api) throw new AppError('configuration_required','Falta configurar GEMINI_API_KEY en el servidor.',503);
        const userMessage=text=>({role:'user',parts:[{text}]});
        const messages=[userMessage(userTemplate.replace('{{request_json}}',JSON.stringify(input)))];
        const call=async(stage,params)=>{
          const request=structuredClone({model,contents:params.contents,config:{systemInstruction:system,maxOutputTokens:10000,...params.config}});
          const event={stage,request:clean(request)}; trace.push(event);
          try {
            event.response=clean(await api.models.generateContent(request));
            event.usage_metadata=event.response.usageMetadata??null;
            event.grounding_metadata=event.response.candidates?.[0]?.groundingMetadata??null;
          }
          catch(e) {
            const detail=clean(String(e.message||'La solicitud a Gemini falló.'));
            event.error={code:e.code||'api_error',status:e.status||null,message:detail};
            if(/(?:billing|paid tier|payment).*(?:required|enable)|(?:enable|requires?).*(?:billing|paid tier)/i.test(detail)) throw new AppError('paid_tier_required','BLOCKED — PAID TIER REQUIRED. No se habilitó facturación.',402);
            if(e.status===429) throw new AppError('quota_exceeded','Cuota de Gemini agotada. No se reintentó ni se habilitó pago.',429);
            throw new AppError(stage==='search'?'search_failed':'api_error','No se pudo completar la solicitud externa.',502);
          }
          const candidate=event.response.candidates?.[0];
          if(event.response.promptFeedback?.blockReason || ['SAFETY','RECITATION','BLOCKLIST','PROHIBITED_CONTENT','SPII'].includes(candidate?.finishReason)) throw new AppError('model_refusal','El modelo no pudo atender esta solicitud.',422);
          if(!candidate?.content || (candidate.finishReason && candidate.finishReason!=='STOP')) throw new AppError('incomplete_response','La respuesta externa no se completó.',502);
          return event.response;
        };
        // Force a real function call before generation. The service binds identity, never trusts model-supplied IDs.
        const stateResponse=await call('progress',{contents:messages,config:{tools:[{functionDeclarations:[progressTool]}],toolConfig:{functionCallingConfig:{mode:'ANY',allowedFunctionNames:['get_learning_progress']}}}});
        messages.push(stateResponse.candidates[0].content);
        const calls=stateResponse.candidates[0].content.parts.filter(p=>p.functionCall).map(p=>p.functionCall);
        if(calls.length!==1 || calls[0].name!=='get_learning_progress') throw new AppError('tool_protocol_error','No se recibió la llamada de progreso requerida.',502);
        let args;
        args=calls[0].args;
        if(!args || args.user_id!==userId || Object.keys(args).some(k=>!['user_id','area','metric'].includes(k)) ||
          !['area','metric'].every(k=>args[k]===null || (typeof args[k]==='string' && args[k].length<=200))) {
          throw new AppError('tool_scope_error','La consulta de progreso no corresponde a esta sesión.',403);
        }
        const progress=store.progress(userId,args.area,args.metric);
        trace.push(clean({stage:'tool_result',name:'get_learning_progress',call_id:calls[0].id??null,arguments:args,output:progress}));
        messages.push({role:'user',parts:[{functionResponse:{name:calls[0].name,...(calls[0].id?{id:calls[0].id}:{}),response:{result:progress}}}]});
        let sources=[];
        if(operation==='module' || operation==='route') {
          const search=await call('search',{contents:[...messages,userMessage('Usá Google Search para recuperar evidencia externa. Citá fuentes y autoridad. No generes todavía el módulo ni la ruta.')],config:{tools:[{googleSearch:{}}]}});
          sources=retrievedSources(search);
          if(!sources.length) throw new AppError('insufficient_sources','La búsqueda no devolvió fuentes trazables.',422);
          messages.push(search.candidates[0].content,userMessage('Fuentes recuperadas permitidas (URIs exactas de grounding metadata): '+JSON.stringify(sources)));
        }
        messages.push(userMessage('Generá ahora la salida estructurada de la operación solicitada. No emitas nuevas llamadas a herramientas.'));
        for(let attempt=0;attempt<2;attempt++) {
          const response=await call('structured',{contents:messages,config:{responseMimeType:'application/json',responseJsonSchema:envelope(operation)}});
          try {
            output=parseEnvelope(operation,textOf(response));
            if(operation==='module' && (output.module_id!==data.module_id || output.version!==1)) throw new AppError('invalid_output','El módulo cambió la identidad asignada.',422);
            if(operation==='route' && output.route_id!==data.route_id) throw new AppError('invalid_output','La ruta cambió la identidad asignada.',422);
            if(operation==='quiz') {
              if(output.quiz_id!==data.quiz_id || output.version!==1) throw new AppError('invalid_output','El quiz cambió la identidad asignada.',422);
              validateQuizSources(output,data.module);
              ensureAlternative(output,data.previous_quiz);
            }
            if(operation==='module' || operation==='route') validateSources(output,sources);
            break;
          } catch(e) {
            output=null;
            if(e.code!=='invalid_output' || attempt===1) throw e;
            messages.push(response.candidates[0].content,userMessage(`Único reintento por error estructural: ${e.message}. Corregí la estructura usando la misma evidencia.`));
          }
        }
        store.finishRun(runId,clean(trace),clean(output),'completed');
        return {data:output,run_id:runId};
      } catch(e) {
        const error=e instanceof AppError?e:new AppError('agent_error','Falló la ejecución del agente.',500);
        store.finishRun(runId,clean(trace),clean(output),'failed',JSON.stringify(clean({code:error.code,message:error.message})));
        error.run_id=runId;
        throw error;
      }
    }
  };
}
